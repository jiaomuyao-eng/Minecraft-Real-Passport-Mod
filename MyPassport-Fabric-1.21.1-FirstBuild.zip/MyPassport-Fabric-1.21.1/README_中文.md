# 《我的护照》Fabric Mod — 第一阶段源码

## 项目配置
- Minecraft Java Edition：1.21.1
- Fabric Loader / Fabric API
- Java：21
- 模组 ID：`my_passport`
- 物品 ID：`my_passport:passport`

## 当前包含
- 暗红色、金色装饰的像素风护照图标
- 手持模型缩放配置（第一/第三人称 0.38）
- 护照物品，使用时打开资料界面
- 界面显示玩家名和基于玩家名生成的游戏专属编号
- 资料页、角色照片占位框、签证/旅行记录占位线
- GitHub Actions 云端构建工作流

## 目前还未完成
- 尚未编译或在游戏中测试，因此这是源码 ZIP，不是可直接安装的 JAR。
- 角色照片目前为占位框。要精确使用你的角色皮肤，最好上传原始皮肤 PNG 文件；聊天中的截图不能直接作为完整皮肤贴图。
- 签证、盖章和旅行记录目前是界面占位，后续阶段再加入可保存的数据功能。

## 云端编译（手机也可以操作）
1. 登录 https://github.com 并新建仓库。
2. 解压此 ZIP，把里面所有文件上传到仓库根目录，确保 `.github/workflows/build.yml` 也上传。
3. 打开仓库的 **Actions**。
4. 选择 **Build MyPassport Fabric Mod**，点击 **Run workflow**。
5. 构建成功后，进入该次运行记录，在 **Artifacts** 下载 `my-passport-fabric-1.21.1`。
6. 解压 Artifact，取出 JAR 放进游戏实例的 `mods` 文件夹。
7. 游戏实例需安装 Minecraft Java 1.21.1、Fabric Loader 和匹配的 Fabric API。

如果 Actions 显示失败，请把失败日志截图发来，我可以根据错误继续修复。

## 说明
护照是虚构游戏道具，使用虚构证件标识，不对应现实国家的官方证件。
