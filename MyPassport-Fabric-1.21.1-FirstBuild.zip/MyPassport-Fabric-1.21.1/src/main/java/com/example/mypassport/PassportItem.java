package com.example.mypassport;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class PassportItem extends Item {
    public PassportItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, net.minecraft.entity.player.PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient && user == MinecraftClient.getInstance().player) {
            MinecraftClient.getInstance().setScreen(new PassportScreen());
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
