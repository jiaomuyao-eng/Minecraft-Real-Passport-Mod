package com.example.mypassport;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class MyPassportMod implements ModInitializer {
    public static final String MOD_ID = "my_passport";
    public static final Item PASSPORT = Registry.register(
        Registries.ITEM,
        Identifier.of(MOD_ID, "passport"),
        new PassportItem(new Item.Settings().maxCount(1))
    );

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS)
            .register(entries -> entries.add(PASSPORT));
    }
}
