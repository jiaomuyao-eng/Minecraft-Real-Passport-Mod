package com.example.mypassport;

import net.fabricmc.api.ClientModInitializer;

public class MyPassportClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // 客户端入口预留：后续可在这里注册音效、渲染等功能。
    }
}
