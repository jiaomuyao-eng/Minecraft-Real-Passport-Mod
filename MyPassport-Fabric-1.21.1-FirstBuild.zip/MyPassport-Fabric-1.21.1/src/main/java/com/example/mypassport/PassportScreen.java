package com.example.mypassport;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class PassportScreen extends Screen {
    public PassportScreen() {
        super(Text.literal("我的护照"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int left = this.width / 2 - 112;
        int top = this.height / 2 - 128;
        int right = this.width / 2 + 112;
        int bottom = this.height / 2 + 128;

        // Outer cover and cream-colored passport page
        context.fill(left, top, right, bottom, 0xFF351219);
        context.fill(left + 5, top + 5, right - 5, bottom - 5, 0xFFE9DCC0);
        context.fill(left + 10, top + 10, right - 10, top + 42, 0xFF6A202D);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("虚构旅行护照").formatted(Formatting.GOLD),
                this.width / 2, top + 22, 0xFFFFD66B);

        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("MINECRAFT TRAVEL DOCUMENT"),
                this.width / 2, top + 51, 0xFF514537);

        // Portrait placeholder; replaceable with the player's skin portrait in a later stage
        context.fill(left + 17, top + 68, left + 82, top + 143, 0xFFBDAE91);
        context.fill(left + 23, top + 75, left + 76, top + 136, 0xFFD9CBAE);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("角色照片"),
                left + 49, top + 101, 0xFF655743);

        String playerName = client != null && client.player != null
                ? client.player.getName().getString() : "Player";
        String number = "MC-" + Integer.toHexString(playerName.hashCode()).toUpperCase();

        context.drawText(textRenderer, Text.literal("玩家姓名"), left + 91, top + 72, 0xFF625747, false);
        context.drawText(textRenderer, Text.literal(playerName), left + 91, top + 88, 0xFF211D18, false);
        context.drawText(textRenderer, Text.literal("游戏编号"), left + 91, top + 111, 0xFF625747, false);
        context.drawText(textRenderer, Text.literal(number), left + 91, top + 127, 0xFF211D18, false);

        context.fill(left + 17, top + 154, right - 17, top + 155, 0xFFB7A98D);
        context.drawText(textRenderer, Text.literal("签证与旅行记录"), left + 17, top + 164, 0xFF514537, false);
        for (int i = 0; i < 3; i++) {
            int y = top + 184 + i * 16;
            context.fill(left + 17, y, right - 17, y + 1, 0xFFB7A98D);
        }
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("ESC 关闭").formatted(Formatting.GRAY),
                this.width / 2, bottom - 20, 0xFF514537);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
